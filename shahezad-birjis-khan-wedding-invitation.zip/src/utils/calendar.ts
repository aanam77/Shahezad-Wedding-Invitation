/**
 * Calendar helpers for Google Calendar and iCalendar (.ics)
 */

export function createGoogleCalendarUrl(event: {
  title: string;
  description: string;
  location: string;
  startIsoIST: string; // e.g. "2026-11-22T18:30:00+05:30"
  durationHours: number;
}): string {
  // Convert ISO string with timezone to UTC compact format: YYYYMMDDTHHmmssZ
  const startDate = new Date(event.startIsoIST);
  const endDate = new Date(startDate.getTime() + event.durationHours * 60 * 60 * 1000);

  const formatUtc = (d: Date) =>
    d.toISOString().replace(/-|:|\.\d+/g, '');

  const startUtc = formatUtc(startDate);
  const endUtc = formatUtc(endDate);

  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: event.title,
    details: event.description,
    location: event.location,
    dates: `${startUtc}/${endUtc}`,
  });

  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

export function downloadIcsFile(event: {
  title: string;
  description: string;
  location: string;
  startIsoIST: string;
  durationHours: number;
  filename: string;
}) {
  const startDate = new Date(event.startIsoIST);
  const endDate = new Date(startDate.getTime() + event.durationHours * 60 * 60 * 1000);

  const formatUtc = (d: Date) =>
    d.toISOString().replace(/-|:|\.\d+/g, '');

  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Shahezad Birjis Khan Wedding//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${Date.now()}@wedding-shahezad-khan`,
    `DTSTAMP:${formatUtc(new Date())}`,
    `DTSTART:${formatUtc(startDate)}`,
    `DTEND:${formatUtc(endDate)}`,
    `SUMMARY:${event.title}`,
    `DESCRIPTION:${event.description.replace(/\n/g, '\\n')}`,
    `LOCATION:${event.location}`,
    'STATUS:CONFIRMED',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${event.filename}.ics`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
