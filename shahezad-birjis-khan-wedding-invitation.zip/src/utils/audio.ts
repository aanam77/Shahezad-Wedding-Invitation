/**
 * Spiritual & tranquil ambient soundscape generator using Web Audio API.
 * Synthesizes soft, gentle acoustic harmonic bells and a meditative warm pad.
 * Instrumental-free, purely meditative and tranquil.
 * Safe, zero-network dependency, zero copyright issue, non-intrusive.
 */

class AmbientSoundscape {
  private ctx: AudioContext | null = null;
  private isRunning: boolean = false;
  private masterGain: GainNode | null = null;
  private intervalId: number | null = null;
  private padOsc1: OscillatorNode | null = null;
  private padOsc2: OscillatorNode | null = null;
  private padGain: GainNode | null = null;

  // Meditative frequencies (gentle acoustic bells in tranquil harmonics: D, F#, A, B, E)
  private readonly bellFrequencies = [
    293.66, // D4
    329.63, // E4
    369.99, // F#4
    440.00, // A4
    493.88, // B4
    587.33, // D5
    659.25, // E5
    739.99, // F#5
    880.00, // A5
  ];

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
  }

  public async start(): Promise<boolean> {
    this.init();
    if (!this.ctx) return false;

    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }

    if (this.isRunning) return true;

    // Master Gain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.001, this.ctx.currentTime);
    this.masterGain.gain.exponentialRampToValueAtTime(0.25, this.ctx.currentTime + 2);
    this.masterGain.connect(this.ctx.destination);

    // Subtle warm drone / meditative pad
    this.startWarmPad();

    // Random gentle harmonic bell plucks
    this.startBellSequence();

    this.isRunning = true;
    return true;
  }

  private startWarmPad() {
    if (!this.ctx || !this.masterGain) return;

    this.padGain = this.ctx.createGain();
    this.padGain.gain.setValueAtTime(0.06, this.ctx.currentTime);

    // Low pass filter for warm organic warmth
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(450, this.ctx.currentTime);
    filter.Q.setValueAtTime(1.5, this.ctx.currentTime);

    this.padOsc1 = this.ctx.createOscillator();
    this.padOsc2 = this.ctx.createOscillator();

    this.padOsc1.type = 'sine';
    this.padOsc1.frequency.setValueAtTime(146.83, this.ctx.currentTime); // D3

    this.padOsc2.type = 'triangle';
    this.padOsc2.frequency.setValueAtTime(220.00, this.ctx.currentTime); // A3

    this.padOsc1.connect(filter);
    this.padOsc2.connect(filter);
    filter.connect(this.padGain);
    this.padGain.connect(this.masterGain);

    this.padOsc1.start();
    this.padOsc2.start();
  }

  private playBell(freq: number) {
    if (!this.ctx || !this.masterGain || !this.isRunning) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const bellGain = this.ctx.createGain();

    // High subtle harmonics
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    // Envelope: instant soft attack, long delicate decay like a crystal singing bowl
    bellGain.gain.setValueAtTime(0.0001, now);
    bellGain.gain.exponentialRampToValueAtTime(0.08, now + 0.05);
    bellGain.gain.exponentialRampToValueAtTime(0.0001, now + 4.5);

    osc.connect(bellGain);
    bellGain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 4.8);
  }

  private startBellSequence() {
    const triggerNext = () => {
      if (!this.isRunning) return;
      const randomFreq = this.bellFrequencies[Math.floor(Math.random() * this.bellFrequencies.length)];
      this.playBell(randomFreq);

      // Next bell in 2.2 to 4.5 seconds for a serene, unhurried pace
      const nextDelay = 2200 + Math.random() * 2300;
      this.intervalId = window.setTimeout(triggerNext, nextDelay);
    };

    triggerNext();
  }

  public stop() {
    if (!this.isRunning || !this.ctx || !this.masterGain) return;

    const now = this.ctx.currentTime;
    this.masterGain.gain.cancelScheduledValues(now);
    this.masterGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

    setTimeout(() => {
      if (this.intervalId) {
        window.clearTimeout(this.intervalId);
        this.intervalId = null;
      }
      try {
        this.padOsc1?.stop();
        this.padOsc2?.stop();
        this.padOsc1?.disconnect();
        this.padOsc2?.disconnect();
      } catch {
        // ignore already stopped
      }
      this.isRunning = false;
    }, 1250);
  }

  public getIsPlaying(): boolean {
    return this.isRunning;
  }
}

export const soundscape = new AmbientSoundscape();
