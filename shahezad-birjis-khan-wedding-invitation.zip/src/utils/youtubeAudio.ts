/**
 * YouTube Audio Controller for Wedding Nasheed:
 * Video ID: EKr4DoJ2DA4
 * Title: Beautiful Wedding Nasheed (عروسة النور - Aroosat An-Noor)
 */

import { soundscape } from './audio';

declare global {
  interface Window {
    onYouTubeIframeAPIReady?: () => void;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    YT?: any;
  }
}

export const NASHEED_INFO = {
  videoId: 'EKr4DoJ2DA4',
  title: 'Wedding Nasheed (عروسة النور)',
  artist: 'Mahmud Huzaifa',
  url: 'https://www.youtube.com/shorts/EKr4DoJ2DA4',
};

type StateListener = (isPlaying: boolean, isReady: boolean) => void;

class YouTubeAudioService {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private player: any = null;
  private isReady: boolean = false;
  private isPlayingState: boolean = false;
  private isApiLoading: boolean = false;
  private listeners: Set<StateListener> = new Set();
  private containerId: string = 'youtube-nasheed-container';
  private fallbackToWebAudio: boolean = false;

  constructor() {
    this.init();
  }

  public init() {
    if (typeof window === 'undefined') return;

    // If already loaded
    if (window.YT && window.YT.Player) {
      this.createPlayer();
      return;
    }

    if (this.isApiLoading) return;
    this.isApiLoading = true;

    // Load YouTube Iframe API script
    const prevReady = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      if (prevReady) prevReady();
      this.createPlayer();
    };

    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    script.async = true;
    script.onerror = () => {
      console.warn('YouTube Iframe API could not be loaded, using fallback audio.');
      this.fallbackToWebAudio = true;
      this.notifyListeners();
    };
    document.head.appendChild(script);
  }

  private createPlayer() {
    if (!window.YT || !window.YT.Player) return;

    let container = document.getElementById(this.containerId);
    if (!container) {
      container = document.createElement('div');
      container.id = this.containerId;
      container.style.position = 'fixed';
      container.style.bottom = '-100px';
      container.style.right = '-100px';
      container.style.width = '10px';
      container.style.height = '10px';
      container.style.opacity = '0';
      container.style.pointerEvents = 'none';
      container.style.zIndex = '-999';
      document.body.appendChild(container);
    }

    try {
      this.player = new window.YT.Player(this.containerId, {
        height: '10',
        width: '10',
        videoId: NASHEED_INFO.videoId,
        playerVars: {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          enablejsapi: 1,
          fs: 0,
          loop: 1,
          playlist: NASHEED_INFO.videoId, // Required for loop to work in YT
          modestbranding: 1,
          playsinline: 1,
          rel: 0,
          origin: window.location.origin,
        },
        events: {
          onReady: () => {
            this.isReady = true;
            this.player.setVolume(85);
            this.notifyListeners();
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          onStateChange: (event: any) => {
            // YT.PlayerState.PLAYING === 1, PAUSED === 2, ENDED === 0
            if (event.data === 1) {
              this.isPlayingState = true;
            } else if (event.data === 2 || event.data === 0) {
              this.isPlayingState = false;
            }
            this.notifyListeners();
          },
          onError: (err: unknown) => {
            console.warn('YouTube playback error, using fallback audio:', err);
            this.fallbackToWebAudio = true;
            this.notifyListeners();
          },
        },
      });
    } catch (e) {
      console.warn('Could not initialize YouTube player:', e);
      this.fallbackToWebAudio = true;
      this.notifyListeners();
    }
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.isPlayingState, this.isReady);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach((l) => l(this.isPlayingState, this.isReady));
  }

  public async play(): Promise<boolean> {
    if (this.fallbackToWebAudio) {
      const res = await soundscape.start();
      this.isPlayingState = true;
      this.notifyListeners();
      return res;
    }

    if (this.player && typeof this.player.playVideo === 'function') {
      try {
        this.player.playVideo();
        this.isPlayingState = true;
        this.notifyListeners();
        return true;
      } catch (err) {
        console.warn('Error calling playVideo:', err);
      }
    }

    // Fallback if not ready yet
    const res = await soundscape.start();
    this.isPlayingState = true;
    this.notifyListeners();
    return res;
  }

  public pause(): void {
    if (this.fallbackToWebAudio || soundscape.getIsPlaying()) {
      soundscape.stop();
    }

    if (this.player && typeof this.player.pauseVideo === 'function') {
      try {
        this.player.pauseVideo();
      } catch (err) {
        console.warn('Error pausing video:', err);
      }
    }

    this.isPlayingState = false;
    this.notifyListeners();
  }

  public async toggle(): Promise<boolean> {
    if (this.isPlayingState) {
      this.pause();
      return false;
    } else {
      return await this.play();
    }
  }

  public isPlaying(): boolean {
    return this.isPlayingState;
  }

  public getNasheedInfo() {
    return NASHEED_INFO;
  }
}

export const youtubeAudio = new YouTubeAudioService();
