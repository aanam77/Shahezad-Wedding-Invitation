import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { InvitationEnvelope } from './components/InvitationEnvelope';
import { AudioPlayer } from './components/AudioPlayer';
import { FloatingParticles } from './components/FloatingParticles';
import { OpeningMessage } from './components/OpeningMessage';
import { HeroSection } from './components/HeroSection';
import { EventCards } from './components/EventCards';
import { CountdownTimer } from './components/CountdownTimer';
import { ContactSection } from './components/ContactSection';
import { ClosingSection } from './components/ClosingSection';
import { IslamicStar } from './components/IslamicMotifs';

export default function App() {
  const [isOpened, setIsOpened] = useState(false);
  const [brideName] = useState(() => {
    try {
      return localStorage.getItem('shahezad_bride_name') || '';
    } catch {
      return '';
    }
  });

  // Ensure any previously saved sample wishes are completely cleared
  useEffect(() => {
    try {
      localStorage.removeItem('shahezad_wedding_wishes');
    } catch {
      // ignore
    }
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF8EE] text-[#4A1D27] relative selection:bg-[#702536] selection:text-[#FFF8EE] font-sans">
      {/* Floating Ambient Gold & Petal Particles */}
      <FloatingParticles density={28} />

      {/* Floating Audio Controller */}
      <AudioPlayer />

      {/* Cinematic Invitation Envelope Opening Modal */}
      <AnimatePresence>
        {!isOpened && (
          <InvitationEnvelope
            onOpen={() => setIsOpened(true)}
            brideName={brideName}
          />
        )}
      </AnimatePresence>

      {/* Main Wedding Invitation Website Content */}
      <main className="relative z-10 transition-opacity duration-1000">
        {/* Subtle Luxury Top Bar */}
        <header className="sticky top-0 z-40 bg-[#FFF8EE]/90 backdrop-blur-md border-b border-[#C6A15B]/30 transition-all">
          <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <IslamicStar className="w-4 h-4 text-[#C6A15B]" />
              <span className="font-serif text-sm sm:text-base font-bold tracking-widest text-[#702536] uppercase">
                Shahezad &amp; Family
              </span>
            </div>

            <nav className="flex items-center gap-4 sm:gap-6 text-xs font-serif uppercase tracking-wider text-[#702536]">
              <button
                onClick={() => scrollToSection('opening-blessing')}
                type="button"
                className="hover:text-[#C6A15B] transition-colors cursor-pointer"
              >
                Blessing
              </button>
              <button
                onClick={() => scrollToSection('hero-section')}
                type="button"
                className="hover:text-[#C6A15B] transition-colors cursor-pointer"
              >
                Groom
              </button>
              <button
                onClick={() => scrollToSection('events-section')}
                type="button"
                className="hover:text-[#C6A15B] transition-colors cursor-pointer"
              >
                Events
              </button>
              <button
                onClick={() => scrollToSection('countdown-section')}
                type="button"
                className="hover:text-[#C6A15B] transition-colors cursor-pointer hidden sm:inline"
              >
                Countdown
              </button>
              <button
                onClick={() => scrollToSection('contact-section')}
                type="button"
                className="hover:text-[#C6A15B] transition-colors cursor-pointer"
              >
                Enquiries
              </button>
            </nav>
          </div>
        </header>

        {/* 1. Islamic Opening Message with sacred blessings */}
        <div id="opening-blessing">
          <OpeningMessage />
        </div>

        {/* 2. Main Hero Section — Groom's Introduction */}
        <div id="hero-section">
          <HeroSection
            brideName={brideName}
            onScrollToCeremony={() => scrollToSection('events-section')}
          />
        </div>

        {/* 3. Live Countdown Timer */}
        <div id="countdown-section">
          <CountdownTimer />
        </div>

        {/* 4. Wedding Ceremony & Reception Cards */}
        <div id="events-section">
          <EventCards />
        </div>

        {/* 5. For Enquiries / Contact Section */}
        <div id="contact-section">
          <ContactSection />
        </div>

        {/* 6. Final Closing Section */}
        <ClosingSection />
      </main>
    </div>
  );
}
