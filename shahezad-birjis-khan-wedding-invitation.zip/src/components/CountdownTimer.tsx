import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { IslamicStar, GoldDivider } from './IslamicMotifs';
import { Heart, Sparkles } from 'lucide-react';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isCompleted: boolean;
}

const CEREMONY_DATE_IST = '2026-11-22T18:30:00+05:30';

export const CountdownTimer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isCompleted: false,
  });

  useEffect(() => {
    const targetTime = new Date(CEREMONY_DATE_IST).getTime();

    const calculateTime = () => {
      const now = Date.now();
      const difference = targetTime - now;

      if (difference <= 0) {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          isCompleted: true,
        });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({
        days,
        hours,
        minutes,
        seconds,
        isCompleted: false,
      });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  const timeBlocks = [
    { label: 'Days', value: timeLeft.days },
    { label: 'Hours', value: timeLeft.hours },
    { label: 'Minutes', value: timeLeft.minutes },
    { label: 'Seconds', value: timeLeft.seconds },
  ];

  return (
    <section className="py-14 sm:py-20 px-4 sm:px-6 bg-[#FFF8EE] relative overflow-hidden">
      {/* Background floral flourishes */}
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="space-y-2 mb-8"
        >
          <div className="flex items-center justify-center gap-2 text-[#C6A15B]">
            <IslamicStar className="w-3.5 h-3.5" />
            <span className="font-serif text-xs uppercase tracking-[0.25em] font-semibold text-[#702536]">
              Auspicious Countdown
            </span>
            <IslamicStar className="w-3.5 h-3.5" />
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl text-[#702536] font-bold tracking-wide">
            Counting Down To The Sacred Union
          </h2>
          <p className="font-cormorant italic text-base sm:text-lg text-[#702536]/80">
            Sunday, 22 November 2026 · 6:30 PM IST (Baad Namaz-e-Magrib)
          </p>
          <GoldDivider className="max-w-xs mx-auto" />
        </motion.div>

        {timeLeft.isCompleted ? (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="p-8 rounded-2xl bg-gradient-to-r from-[#702536] via-[#8C3146] to-[#702536] text-[#FFF8EE] border-2 border-[#DFBA71] shadow-2xl max-w-xl mx-auto"
          >
            <Sparkles className="w-8 h-8 text-[#DFBA71] mx-auto mb-2" />
            <h3 className="font-serif text-2xl sm:text-3xl font-bold mb-2">
              Alhamdulillah! The Celebrations Have Commenced
            </h3>
            <p className="font-cormorant text-lg text-[#EAD8B2] italic">
              “Barakallahu laka wa baraka 'alaika wa jama'a bainakuma fi khair.”
            </p>
            <p className="text-xs uppercase tracking-widest text-[#FFF8EE]/80 mt-2">
              May Allah bless this union with eternal love and peace.
            </p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-6 max-w-2xl mx-auto">
            {timeBlocks.map((block, idx) => (
              <motion.div
                key={block.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="group relative flex flex-col items-center justify-center p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-[#702536] via-[#5C1C2A] to-[#40121C] border border-[#DFBA71]/70 shadow-lg shadow-[#702536]/20 transition-transform duration-300 hover:scale-105"
              >
                {/* Gold inner outline */}
                <div className="absolute inset-1.5 rounded-xl border border-dashed border-[#DFBA71]/30 pointer-events-none" />

                {/* Corner golden dot */}
                <div className="absolute top-2 left-2 w-1 h-1 rounded-full bg-[#DFBA71]" />
                <div className="absolute top-2 right-2 w-1 h-1 rounded-full bg-[#DFBA71]" />
                <div className="absolute bottom-2 left-2 w-1 h-1 rounded-full bg-[#DFBA71]" />
                <div className="absolute bottom-2 right-2 w-1 h-1 rounded-full bg-[#DFBA71]" />

                {/* Number Display */}
                <span className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#FFF8EE] tracking-tight group-hover:text-[#DFBA71] transition-colors drop-shadow-sm">
                  {String(block.value).padStart(2, '0')}
                </span>

                {/* Label */}
                <span className="mt-1 font-serif text-[11px] sm:text-xs uppercase tracking-[0.2em] text-[#DFBA71] font-medium">
                  {block.label}
                </span>
              </motion.div>
            ))}
          </div>
        )}

        <div className="mt-8 flex items-center justify-center gap-2 text-xs font-serif tracking-widest text-[#C6A15B] uppercase">
          <Heart className="w-3.5 h-3.5 fill-[#702536] text-[#702536]" />
          <span>With Prayers & Joy</span>
          <Heart className="w-3.5 h-3.5 fill-[#702536] text-[#702536]" />
        </div>
      </div>
    </section>
  );
};
