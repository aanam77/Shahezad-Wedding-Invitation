import React from 'react';
import { motion } from 'motion/react';
import { BismillahCalligraphy, GoldFloralCorner, GoldDivider, IslamicStar, MihrabArchBackdrop } from './IslamicMotifs';

export const OpeningMessage: React.FC = () => {
  return (
    <section className="relative py-16 sm:py-24 px-4 sm:px-6 bg-[#FFF8EE] islamic-pattern-bg overflow-hidden">
      {/* Background Ambient Glow & Arch (Strictly in background layer -z-0) */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-96 bg-gradient-to-r from-[#DFBA71]/12 via-[#FFF8EE] to-[#702536]/10 blur-3xl pointer-events-none -z-0" />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none -z-0 opacity-40">
        <MihrabArchBackdrop className="w-[500px] h-[600px]" />
      </div>

      <div className="relative z-10 max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.9, ease: 'easeOut' }}
          className="relative rounded-3xl bg-gradient-to-b from-[#FFFDF9]/95 via-[#FFF8EE]/95 to-[#FAF2E4]/90 border border-[#C6A15B]/40 p-6 sm:p-12 md:p-16 shadow-xl luxury-card-shadow text-center backdrop-blur-xs"
        >
          {/* Subtle Corner Accents (Placed strictly in outer corners, unobstructing any text) */}
          <div className="absolute top-2.5 left-2.5 pointer-events-none opacity-70">
            <GoldFloralCorner position="top-left" className="w-10 h-10 sm:w-14 sm:h-14" />
          </div>
          <div className="absolute top-2.5 right-2.5 pointer-events-none opacity-70">
            <GoldFloralCorner position="top-right" className="w-10 h-10 sm:w-14 sm:h-14" />
          </div>
          <div className="absolute bottom-2.5 left-2.5 pointer-events-none opacity-70">
            <GoldFloralCorner position="bottom-left" className="w-10 h-10 sm:w-14 sm:h-14" />
          </div>
          <div className="absolute bottom-2.5 right-2.5 pointer-events-none opacity-70">
            <GoldFloralCorner position="bottom-right" className="w-10 h-10 sm:w-14 sm:h-14" />
          </div>

          {/* Inner hairline border */}
          <div className="absolute inset-2.5 sm:inset-3 rounded-2xl border border-[#DFBA71]/30 pointer-events-none" />

          {/* Editorial Kicker */}
          <div className="flex items-center justify-center gap-2 mb-4">
            <IslamicStar className="w-3.5 h-3.5 text-[#C6A15B]" />
            <span className="font-sans text-[11px] uppercase tracking-[0.28em] font-semibold text-[#702536]">
              In The Sacred Presence of The Almighty
            </span>
            <IslamicStar className="w-3.5 h-3.5 text-[#C6A15B]" />
          </div>

          {/* Visual Highlight: Authentic Arabic Bismillah with Ample Breathing Space */}
          <div className="my-6 sm:my-8 px-2">
            <BismillahCalligraphy variant="gold" className="w-full max-w-lg mx-auto" />
          </div>

          {/* Arabic Salawat (Right to Left, Connected HarfBuzz Typography) */}
          <div
            dir="rtl"
            lang="ar"
            className="my-3 text-center"
          >
            <p
              className="font-arabic text-xl sm:text-2xl text-[#702536] font-medium tracking-wide drop-shadow-xs"
              style={{
                fontFamily: "'Noto Naskh Arabic', 'Amiri', 'Traditional Arabic', serif",
              }}
            >
              صَلَّىٰ اللّٰهُ عَلَيْهِ وَسَلَّمَ
            </p>
          </div>

          <div className="max-w-xs mx-auto my-5">
            <GoldDivider />
          </div>

          {/* Exact Verified Islamic Opening Message — Protected & Clean */}
          <blockquote className="my-6 sm:my-8">
            <p className="font-cormorant italic text-lg sm:text-xl md:text-2xl leading-relaxed text-[#501623] px-3 sm:px-8 font-light">
              “In the name of Allah, the most beneficent, with the supreme blessing of Huzoor Nabi-e-Karim, Ahmed-e-Mujtaba Hazrat Mustafa (S.A.W.), Hazrat Khwaja Moinuddin Hasan Chishti, Gharib Nawaz (R.A.).”
            </p>
          </blockquote>

          {/* Decorative Ayah Section placed strictly AFTER text */}
          <div className="mt-8 pt-6 border-t border-[#C6A15B]/30 flex flex-col items-center gap-2">
            <p
              dir="rtl"
              lang="ar"
              className="font-arabic text-base sm:text-xl text-[#C6A15B] leading-relaxed drop-shadow-2xs"
              style={{
                fontFamily: "'Noto Naskh Arabic', 'Amiri', 'Traditional Arabic', serif",
              }}
            >
              وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا
            </p>
            <span className="font-sans text-[10px] sm:text-[11px] tracking-[0.2em] text-[#702536]/75 uppercase font-medium">
              Surah Ar-Rum · 30:21
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
