import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BismillahCalligraphy, GoldFloralCorner, GoldDivider, IslamicStar, RoyalWaxSeal } from './IslamicMotifs';
import { youtubeAudio } from '../utils/youtubeAudio';
import { Music } from 'lucide-react';

interface InvitationEnvelopeProps {
  onOpen: () => void;
  brideName: string;
}

export const InvitationEnvelope: React.FC<InvitationEnvelopeProps> = ({ onOpen, brideName }) => {
  const [isOpening, setIsOpening] = useState(false);
  const [wantsAudio, setWantsAudio] = useState(false);

  const handleOpenClick = async () => {
    setIsOpening(true);
    if (wantsAudio) {
      await youtubeAudio.play();
    }
    // Allow animation to play majestically before transitioning
    setTimeout(() => {
      onOpen();
    }, 1100);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.9, ease: 'easeInOut' }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden bg-[#FFF8EE] islamic-pattern-bg select-none"
    >
      {/* Decorative Outer Ambient Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-[#DFBA71]/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-[#702536]/10 blur-3xl pointer-events-none" />

      {/* Main Luxury Envelope / Folio Container */}
      <motion.div
        initial={{ scale: 0.92, y: 30, opacity: 0 }}
        animate={{
          scale: isOpening ? [1, 1.04, 0.95] : 1,
          y: isOpening ? -20 : 0,
          opacity: isOpening ? [1, 1, 0] : 1,
        }}
        transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-xl mx-auto"
      >
        {/* Envelope Folio Card */}
        <div className="relative rounded-2xl bg-gradient-to-b from-[#FFFDF9] via-[#FFF8EE] to-[#FBF3E4] p-6 sm:p-10 md:p-12 shadow-[0_25px_60px_-15px_rgba(112,37,54,0.2)] border-2 border-[#C6A15B]/50 overflow-hidden">
          {/* Subtle Islamic lattice watermark */}
          <div className="absolute inset-0 opacity-[0.035] islamic-pattern-dark pointer-events-none" />

          {/* Gold Filigree Corner Ornaments with reveal animation */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="absolute top-3 left-3"
          >
            <GoldFloralCorner position="top-left" className="w-12 h-12 sm:w-16 sm:h-16" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="absolute top-3 right-3"
          >
            <GoldFloralCorner position="top-right" className="w-12 h-12 sm:w-16 sm:h-16" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="absolute bottom-3 left-3"
          >
            <GoldFloralCorner position="bottom-left" className="w-12 h-12 sm:w-16 sm:h-16" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="absolute bottom-3 right-3"
          >
            <GoldFloralCorner position="bottom-right" className="w-12 h-12 sm:w-16 sm:h-16" />
          </motion.div>

          {/* Inner Golden Border Frame with stroke drawing animation */}
          <div className="absolute inset-3 sm:inset-4 rounded-xl border border-[#DFBA71]/50 pointer-events-none" />
          <div className="absolute inset-4 sm:inset-5 rounded-lg border border-dashed border-[#C6A15B]/30 pointer-events-none" />

          {/* Card Content with staggered entrance */}
          <div className="relative z-10 flex flex-col items-center text-center">
            {/* Islamic Bismillah Calligraphy */}
            <motion.div
              initial={{ opacity: 0, y: -15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="w-full max-w-[280px] sm:max-w-[340px] mb-3"
            >
              <BismillahCalligraphy className="w-full" />
            </motion.div>

            {/* Sub-header / Formal invitation honorific */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="space-y-1 mb-4"
            >
              <p className="font-serif text-[11px] sm:text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">
                Royal Wedding Invitation
              </p>
              <p className="font-cormorant italic text-sm sm:text-base text-[#702536]/80">
                Together with our families, we cordially invite you to celebrate
              </p>
            </motion.div>

            {/* Groom and Bride Spotlight */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.9 }}
              className="my-3 sm:my-4 space-y-2 w-full"
            >
              <h1 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold tracking-wider text-[#702536] drop-shadow-sm">
                SHAHEZAD
              </h1>
              <p className="font-script text-2xl sm:text-3xl text-[#C6A15B] -my-1 font-normal">
                weds
              </p>
              <p className="font-serif text-base sm:text-lg tracking-wide text-[#702536] font-medium">
                {brideName || 'Daughter of Ezaz Gafur Shaikh'}
              </p>
            </motion.div>

            {/* Ornamental Divider */}
            <motion.div
              initial={{ opacity: 0, scaleX: 0.4 }}
              animate={{ opacity: 1, scaleX: 1 }}
              transition={{ delay: 0.7, duration: 0.7 }}
              className="w-full max-w-xs"
            >
              <GoldDivider className="my-3" />
            </motion.div>

            {/* Date and Location Teaser */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="mb-6 space-y-1"
            >
              <p className="font-serif text-xs sm:text-sm tracking-widest text-[#501623] font-medium uppercase">
                Sunday, 22 November 2026
              </p>
              <p className="font-sans text-[11px] sm:text-xs tracking-wider text-[#702536]/70">
                Al Noor Lawn · Ahmednagar
              </p>
            </motion.div>

            {/* Interactive Royal Wax Seal & Action Button */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.9, duration: 0.6, type: 'spring' }}
              className="flex flex-col items-center gap-4"
            >
              <RoyalWaxSeal
                onClick={handleOpenClick}
                isOpening={isOpening}
                className="hover:shadow-2xl"
              />

              <button
                type="button"
                onClick={handleOpenClick}
                disabled={isOpening}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-3.5 rounded-full bg-gradient-to-r from-[#702536] via-[#8C3146] to-[#702536] text-[#FFF8EE] font-serif text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase shadow-lg shadow-[#702536]/25 border border-[#DFBA71]/60 transition-all duration-300 hover:shadow-xl hover:shadow-[#C6A15B]/30 hover:scale-[1.03] active:scale-95 cursor-pointer disabled:opacity-80"
              >
                {/* Gold sparkle border accent */}
                <span className="w-1.5 h-1.5 rotate-45 bg-[#DFBA71] group-hover:rotate-90 transition-transform duration-500" />
                <span>{isOpening ? 'Revealing Invitation...' : 'Open Your Invitation'}</span>
                <span className="w-1.5 h-1.5 rotate-45 bg-[#DFBA71] group-hover:rotate-90 transition-transform duration-500" />
              </button>

              {/* Wedding Nasheed Audio Option Toggle */}
              <label className="flex items-center gap-2 cursor-pointer text-xs text-[#702536]/90 hover:text-[#702536] transition-colors mt-1 select-none">
                <input
                  type="checkbox"
                  checked={wantsAudio}
                  onChange={(e) => setWantsAudio(e.target.checked)}
                  className="rounded border-[#C6A15B] text-[#702536] focus:ring-[#C6A15B] focus:ring-offset-0 cursor-pointer"
                />
                <span className="font-cormorant italic text-sm flex items-center gap-1.5">
                  <Music className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Play Wedding Nasheed on opening (عروسة النور)</span>
                </span>
              </label>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
