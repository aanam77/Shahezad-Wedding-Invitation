import React from 'react';
import { motion } from 'motion/react';
import { GoldFloralCorner, GoldDivider, IslamicStar } from './IslamicMotifs';
import { Phone, MessageCircle, HelpCircle } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const contacts = [
    {
      name: 'Bahezad Khan',
      displayPhone: '+91 80873 81107',
      telNumber: '+918087381107',
      waNumber: '918087381107',
      waMessage: 'Assalamu Alaikum Bahezad bhai, regarding the wedding invitation of Shahezad Birjis Khan.',
    },
    {
      name: 'ARIB KHAN',
      displayPhone: '+91 84596 05952',
      telNumber: '+918459605952',
      waNumber: '918459605952',
      waMessage: 'Assalamu Alaikum Arib bhai, regarding the wedding invitation of Shahezad Birjis Khan.',
    },
  ];

  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6 bg-[#FFF8EE] relative overflow-hidden">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-xl mx-auto mb-12"
        >
          <div className="flex items-center justify-center gap-2 text-[#C6A15B] mb-2">
            <IslamicStar className="w-3.5 h-3.5" />
            <span className="font-serif text-xs uppercase tracking-[0.25em] font-semibold text-[#702536]">
              Assistance & Hospitality
            </span>
            <IslamicStar className="w-3.5 h-3.5" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#702536] font-bold tracking-wide">
            For Enquiries
          </h2>
          <p className="font-cormorant italic text-base sm:text-lg text-[#702536]/80 mt-1">
            Please feel free to connect with our family coordinators for directions or questions
          </p>
          <GoldDivider className="max-w-xs mx-auto" />
        </motion.div>

        {/* Contacts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {contacts.map((contact, idx) => (
            <motion.div
              key={contact.name}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: idx * 0.15 }}
              className="relative rounded-2xl bg-gradient-to-b from-[#FFFDF9] to-[#FFF8EE] p-6 sm:p-8 border-2 border-[#C6A15B]/50 shadow-lg shadow-[#702536]/5 flex flex-col justify-between"
            >
              {/* Corner Accents */}
              <div className="absolute top-2 left-2 pointer-events-none">
                <GoldFloralCorner position="top-left" className="w-10 h-10" />
              </div>
              <div className="absolute top-2 right-2 pointer-events-none">
                <GoldFloralCorner position="top-right" className="w-10 h-10" />
              </div>

              <div className="text-center mb-6 pt-2">
                <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#702536]">
                  {contact.name}
                </h3>
                <p className="font-sans text-base sm:text-lg font-semibold text-[#501623] tracking-wide mt-1">
                  {contact.displayPhone}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Call Button */}
                <a
                  href={`tel:${contact.telNumber}`}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#702536] to-[#8C3146] text-[#FFF8EE] font-serif text-xs font-semibold tracking-wider uppercase shadow-sm transition-all duration-300 hover:shadow-md hover:scale-[1.02] active:scale-95"
                >
                  <Phone className="w-3.5 h-3.5 text-[#DFBA71]" />
                  <span>Call {contact.name.split(' ')[0].charAt(0).toUpperCase() + contact.name.split(' ')[0].slice(1).toLowerCase()}</span>
                </a>

                {/* WhatsApp Button */}
                <a
                  href={`https://wa.me/${contact.waNumber}?text=${encodeURIComponent(contact.waMessage)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#25D366] text-white font-serif text-xs font-semibold tracking-wider uppercase shadow-sm transition-all duration-300 hover:bg-[#20BA5A] hover:shadow-md hover:scale-[1.02] active:scale-95"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-current" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
