import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GoldFloralCorner, GoldDivider, IslamicStar } from './IslamicMotifs';
import { MapPin, Calendar, Clock, Navigation, CalendarPlus, ChevronDown } from 'lucide-react';
import { createGoogleCalendarUrl, downloadIcsFile } from '../utils/calendar';

export const EventCards: React.FC = () => {
  const [activeCalendarMenu, setActiveCalendarMenu] = useState<'ceremony' | 'reception' | null>(null);

  const ceremonyEvent = {
    title: 'Nikah & Wedding Ceremony of Shahezad Birjis Khan',
    description: "Nikah and Wedding Ceremony of Shahezad Birjis Khan & Daughter of Ezaz Gafur Shaikh.\nTiming: Baad Namaz-e-Magrib (6:30 PM)\nVenue: Al Noor Lawn, Sahara City, Mukundnagar, Ahmednagar",
    location: 'Al Noor Lawn, Sahara City, Mukundnagar, Ahmednagar, Maharashtra',
    startIsoIST: '2026-11-22T18:30:00+05:30',
    durationHours: 4,
    filename: 'Shahezad_Wedding_Ceremony',
  };

  const receptionEvent = {
    title: 'Walima & Reception of Shahezad Birjis Khan',
    description: "Walima / Reception celebration of Shahezad Birjis Khan.\nTiming: 7:30 PM Onwards\nVenue: City Lawns, Ahmednagar",
    location: 'City Lawns, Ahmednagar, Maharashtra',
    startIsoIST: '2026-11-23T19:30:00+05:30',
    durationHours: 4,
    filename: 'Shahezad_Wedding_Reception',
  };

  return (
    <section id="events-section" className="py-20 sm:py-28 px-4 sm:px-6 bg-[#FFF8EE] islamic-pattern-bg relative">
      <div className="max-w-6xl mx-auto">
        {/* Section Header — Gen Z Luxury Editorial Typography */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <div className="inline-flex items-center justify-center gap-2 px-4 py-1 rounded-full bg-[#FFF8EE] border border-[#C6A15B]/50 shadow-xs mb-3">
            <IslamicStar className="w-3.5 h-3.5 text-[#C6A15B]" />
            <span className="font-sans text-[11px] uppercase tracking-[0.28em] font-semibold text-[#702536]">
              Programme of Celebrations
            </span>
            <IslamicStar className="w-3.5 h-3.5 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#702536] font-bold tracking-wide">
            Wedding Itinerary
          </h2>
          <p className="font-cormorant italic text-base sm:text-xl text-[#702536]/80 mt-2 font-light">
            We solicit the honour of your presence and warm blessings
          </p>
          <GoldDivider className="max-w-xs mx-auto mt-3" />
        </motion.div>

        {/* 2 Event Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-stretch">
          {/* Card 1: WEDDING CEREMONY */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="group relative rounded-3xl bg-gradient-to-b from-[#FFFDF9] via-[#FFF8EE] to-[#FBF2E3] p-6 sm:p-8 md:p-10 border border-[#C6A15B]/60 shadow-xl luxury-card-shadow transition-all duration-500 hover:shadow-2xl hover:border-[#DFBA71] hover:-translate-y-1 flex flex-col justify-between"
          >
            {/* Top Corner Flourishes */}
            <div className="absolute top-2.5 left-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="top-left" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>
            <div className="absolute top-2.5 right-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="top-right" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>
            <div className="absolute bottom-2.5 left-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="bottom-left" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>
            <div className="absolute bottom-2.5 right-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="bottom-right" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>

            {/* Inner Border */}
            <div className="absolute inset-3 rounded-2xl border border-dashed border-[#C6A15B]/30 pointer-events-none" />

            {/* Card Content */}
            <div className="relative z-10">
              {/* Event Badge Header */}
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-12 h-12 rounded-full bg-[#702536] text-[#DFBA71] border border-[#DFBA71] flex items-center justify-center mb-3 shadow-md group-hover:scale-105 transition-transform duration-300">
                  <Calendar className="w-5 h-5 animate-pulse" />
                </div>
                <span className="font-sans text-[11px] uppercase tracking-[0.3em] text-[#C6A15B] font-bold">
                  Sacred Nikah
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#702536] mt-1 tracking-wide">
                  WEDDING CEREMONY
                </h3>
                <GoldDivider className="my-2 max-w-[180px]" />
              </div>

              {/* Date & Time Highlights */}
              <div className="space-y-4 mb-6 bg-[#FFF8EE]/90 rounded-2xl p-5 border border-[#C6A15B]/30">
                <div className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-8 h-8 rounded-xl bg-[#702536]/10 text-[#702536] flex items-center justify-center shrink-0">
                    <Calendar className="w-4 h-4 text-[#702536]" />
                  </div>
                  <div>
                    <p className="font-serif text-base sm:text-lg font-bold text-[#501623]">
                      Sunday, 22 November 2026
                    </p>
                    <p className="font-cormorant italic text-sm text-[#702536]/80">
                      12 Jumada al-Awwal 1448 AH (Approx.)
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-8 h-8 rounded-xl bg-[#702536]/10 text-[#702536] flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4 text-[#702536]" />
                  </div>
                  <div>
                    <p className="font-serif text-base sm:text-lg font-bold text-[#501623]">
                      6:30 PM
                    </p>
                    <p className="font-cormorant italic text-sm text-[#C6A15B] font-semibold">
                      Baad Namaz-e-Magrib
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-8 h-8 rounded-xl bg-[#702536]/10 text-[#702536] flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-[#702536]" />
                  </div>
                  <div>
                    <p className="font-serif text-base font-bold text-[#501623]">
                      Al Noor Lawn
                    </p>
                    <p className="font-sans text-xs sm:text-sm text-[#702536]/80">
                      Sahara City, Mukundnagar, Ahmednagar
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="relative z-10 pt-4 flex flex-col sm:flex-row gap-3">
              {/* Get Directions Button */}
              <a
                href="https://www.google.com/maps/search/?api=1&query=Al+Noor+Lawn+Sahara+City+Mukundnagar+Ahmednagar"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-[#702536] to-[#8C3146] text-[#FFF8EE] font-serif text-xs font-semibold tracking-wider uppercase shadow-md transition-all duration-300 hover:shadow-lg hover:shadow-[#702536]/25 hover:scale-[1.02] active:scale-95 text-center"
              >
                <Navigation className="w-3.5 h-3.5 text-[#DFBA71]" />
                <span>Get Directions</span>
              </a>

              {/* Add to Calendar Button with Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() =>
                    setActiveCalendarMenu(activeCalendarMenu === 'ceremony' ? null : 'ceremony')
                  }
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#FFF8EE] border border-[#C6A15B] text-[#702536] font-serif text-xs font-semibold tracking-wider uppercase transition-colors hover:bg-[#F8EEDD] cursor-pointer"
                >
                  <CalendarPlus className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Add to Calendar</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {activeCalendarMenu === 'ceremony' && (
                  <div className="absolute bottom-full mb-2 right-0 w-48 rounded-xl bg-[#FFF8EE] border border-[#C6A15B] shadow-xl p-1 z-30 flex flex-col gap-1">
                    <a
                      href={createGoogleCalendarUrl(ceremonyEvent)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 text-xs font-serif text-[#702536] hover:bg-[#F2E5D0] rounded-lg transition-colors flex items-center gap-2"
                      onClick={() => setActiveCalendarMenu(null)}
                    >
                      <span>Google Calendar</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => {
                        downloadIcsFile(ceremonyEvent);
                        setActiveCalendarMenu(null);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-serif text-[#702536] hover:bg-[#F2E5D0] rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                    >
                      <span>Apple / Outlook (.ics)</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>

          {/* Card 2: RECEPTION (Cream & Maroon Banquet Theme with Dedicated Photographic Showcase) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="group relative rounded-3xl bg-gradient-to-b from-[#FFFDF9] via-[#FFF8EE] to-[#F5EADB] p-6 sm:p-8 md:p-10 border border-[#C6A15B]/60 shadow-xl luxury-card-shadow transition-all duration-500 hover:shadow-2xl hover:border-[#DFBA71] hover:-translate-y-1 flex flex-col justify-between"
          >
            {/* Top Corner Flourishes */}
            <div className="absolute top-2.5 left-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="top-left" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>
            <div className="absolute top-2.5 right-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="top-right" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>
            <div className="absolute bottom-2.5 left-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="bottom-left" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>
            <div className="absolute bottom-2.5 right-2.5 pointer-events-none opacity-80">
              <GoldFloralCorner position="bottom-right" className="w-12 h-12 sm:w-14 sm:h-14" />
            </div>

            {/* Inner Border */}
            <div className="absolute inset-3 rounded-2xl border border-dashed border-[#C6A15B]/30 pointer-events-none" />

            {/* Card Content */}
            <div className="relative z-10">
              {/* Event Badge Header */}
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-12 h-12 rounded-full bg-[#702536] text-[#DFBA71] border border-[#DFBA71] flex items-center justify-center mb-3 shadow-md group-hover:scale-105 transition-transform duration-300">
                  <IslamicStar className="w-5 h-5 text-[#DFBA71]" />
                </div>
                <span className="font-sans text-[11px] uppercase tracking-[0.3em] text-[#C6A15B] font-bold">
                  Walima Celebration
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#702536] mt-1 tracking-wide">
                  RECEPTION
                </h3>
                <GoldDivider className="my-2 max-w-[180px]" />
              </div>

              {/* Date & Time Highlights */}
              <div className="space-y-4 mb-6 bg-[#FFF8EE]/90 rounded-2xl p-5 border border-[#C6A15B]/30">
                <div className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-8 h-8 rounded-xl bg-[#702536]/10 text-[#702536] flex items-center justify-center shrink-0">
                    <Calendar className="w-4 h-4 text-[#702536]" />
                  </div>
                  <div>
                    <p className="font-serif text-base sm:text-lg font-bold text-[#501623]">
                      Monday, 23 November 2026
                    </p>
                    <p className="font-cormorant italic text-sm text-[#702536]/80">
                      An evening of felicitations & banquet
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-8 h-8 rounded-xl bg-[#702536]/10 text-[#702536] flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4 text-[#702536]" />
                  </div>
                  <div>
                    <p className="font-serif text-base sm:text-lg font-bold text-[#501623]">
                      7:30 PM Onwards
                    </p>
                    <p className="font-cormorant italic text-sm text-[#C6A15B] font-semibold">
                      Dinner & Greetings
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-8 h-8 rounded-xl bg-[#702536]/10 text-[#702536] flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-[#702536]" />
                  </div>
                  <div>
                    <p className="font-serif text-base font-bold text-[#501623]">
                      City Lawns
                    </p>
                    <p className="font-sans text-xs sm:text-sm text-[#702536]/80">
                      Ahmednagar, Maharashtra
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="relative z-10 pt-4 flex flex-col sm:flex-row gap-3">
              {/* Get Directions Button */}
              <a
                href="https://www.google.com/maps/search/?api=1&query=City+Lawns+Ahmednagar"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-[#702536] to-[#8C3146] text-[#FFF8EE] font-serif text-xs font-semibold tracking-wider uppercase shadow-md transition-all duration-300 hover:shadow-lg hover:shadow-[#702536]/25 hover:scale-[1.02] active:scale-95 text-center"
              >
                <Navigation className="w-3.5 h-3.5 text-[#DFBA71]" />
                <span>Get Directions</span>
              </a>

              {/* Add to Calendar Button with Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() =>
                    setActiveCalendarMenu(activeCalendarMenu === 'reception' ? null : 'reception')
                  }
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#FFF8EE] border border-[#C6A15B] text-[#702536] font-serif text-xs font-semibold tracking-wider uppercase transition-colors hover:bg-[#F8EEDD] cursor-pointer"
                >
                  <CalendarPlus className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Add to Calendar</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {activeCalendarMenu === 'reception' && (
                  <div className="absolute bottom-full mb-2 right-0 w-48 rounded-xl bg-[#FFF8EE] border border-[#C6A15B] shadow-xl p-1 z-30 flex flex-col gap-1">
                    <a
                      href={createGoogleCalendarUrl(receptionEvent)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 text-xs font-serif text-[#702536] hover:bg-[#F2E5D0] rounded-lg transition-colors flex items-center gap-2"
                      onClick={() => setActiveCalendarMenu(null)}
                    >
                      <span>Google Calendar</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => {
                        downloadIcsFile(receptionEvent);
                        setActiveCalendarMenu(null);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-serif text-[#702536] hover:bg-[#F2E5D0] rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                    >
                      <span>Apple / Outlook (.ics)</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
