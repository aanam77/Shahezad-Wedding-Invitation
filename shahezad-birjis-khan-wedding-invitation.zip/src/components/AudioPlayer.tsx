import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Music } from 'lucide-react';
import { youtubeAudio } from '../utils/youtubeAudio';

export const AudioPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    const unsubscribe = youtubeAudio.subscribe((playing) => {
      setIsPlaying(playing);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const toggleAudio = async () => {
    setHasInteracted(true);
    await youtubeAudio.toggle();
  };

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col items-end gap-1.5">
      <div className="flex items-center gap-2">
        <button
          onClick={toggleAudio}
          type="button"
          aria-label={isPlaying ? 'Pause wedding nasheed' : 'Play wedding nasheed'}
          className="group relative flex items-center gap-2.5 px-3.5 py-2 rounded-full bg-[#FFF8EE]/95 border border-[#C6A15B]/60 text-[#702536] shadow-lg backdrop-blur-md transition-all duration-300 hover:border-[#C6A15B] hover:shadow-[#C6A15B]/20 hover:scale-105 active:scale-95 cursor-pointer"
        >
          {/* Animated Equalizer Wave Bars */}
          {isPlaying ? (
            <div className="flex items-end gap-0.5 h-3.5 w-3.5 justify-center">
              <span className="w-0.5 bg-[#C6A15B] rounded-full animate-bounce h-2" style={{ animationDelay: '0ms' }} />
              <span className="w-0.5 bg-[#702536] rounded-full animate-bounce h-3.5" style={{ animationDelay: '150ms' }} />
              <span className="w-0.5 bg-[#C6A15B] rounded-full animate-bounce h-2.5" style={{ animationDelay: '300ms' }} />
            </div>
          ) : (
            <Music className="w-3.5 h-3.5 text-[#C6A15B] group-hover:text-[#702536] transition-colors" />
          )}

          <div className="flex flex-col text-left">
            <span className="font-serif text-[11px] tracking-wider font-semibold text-[#702536] leading-tight">
              {isPlaying ? 'Wedding Nasheed' : 'Play Nasheed'}
            </span>
            <span className="font-arabic text-[10px] text-[#C6A15B] leading-none hidden sm:inline">
              عروسة النور
            </span>
          </div>

          <span className="text-[#C6A15B] group-hover:text-[#702536] transition-colors ml-0.5">
            {isPlaying ? (
              <Volume2 className="w-4 h-4 text-[#702536]" />
            ) : (
              <VolumeX className="w-4 h-4 text-[#C6A15B]" />
            )}
          </span>

          {/* Subtle pulse ring when playing */}
          {isPlaying && (
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#DFBA71] opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#C6A15B]" />
            </span>
          )}
        </button>
      </div>

      {/* First view helper badge */}
      {!hasInteracted && (
        <div className="hidden md:flex items-center gap-1.5 text-[11px] text-[#702536] bg-[#FFF8EE]/95 px-3 py-1 rounded-full border border-[#C6A15B]/50 shadow-sm pointer-events-none animate-pulse">
          <Music className="w-3.5 h-3.5 text-[#C6A15B]" />
          <span>Click to play Wedding Nasheed ♬</span>
        </div>
      )}
    </div>
  );
};
