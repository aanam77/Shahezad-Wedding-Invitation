import React from 'react';
import { motion } from 'motion/react';
import { GoldDivider, GoldFloralCorner, IslamicStar } from './IslamicMotifs';
import { ChevronDown, Calendar } from 'lucide-react';

interface HeroSectionProps {
  brideName: string;
  onOpenBrideModal?: () => void;
  onScrollToCeremony: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  brideName,
  onScrollToCeremony,
}) => {
  return (
    <section className="relative min-h-[92vh] flex flex-col items-center justify-center py-20 sm:py-28 px-4 sm:px-6 bg-gradient-to-b from-[#FFF8EE] via-[#FAF5EC] to-[#FFF8EE] overflow-hidden">
      {/* Background Decorative Ambient Layers (Strictly non-blocking) */}
      <div className="absolute top-4 left-4 z-0 pointer-events-none opacity-60">
        <GoldFloralCorner position="top-left" className="w-16 h-16 sm:w-24 sm:h-24" />
      </div>
      <div className="absolute top-4 right-4 z-0 pointer-events-none opacity-60">
        <GoldFloralCorner position="top-right" className="w-16 h-16 sm:w-24 sm:h-24" />
      </div>
      <div className="absolute bottom-6 left-4 z-0 pointer-events-none opacity-60">
        <GoldFloralCorner position="bottom-left" className="w-16 h-16 sm:w-24 sm:h-24" />
      </div>
      <div className="absolute bottom-6 right-4 z-0 pointer-events-none opacity-60">
        <GoldFloralCorner position="bottom-right" className="w-16 h-16 sm:w-24 sm:h-24" />
      </div>

      {/* Islamic geometric background watermark */}
      <div className="absolute inset-0 islamic-pattern-bg opacity-65 pointer-events-none -z-0" />

      {/* Radial soft maroon & champagne aura */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-gradient-to-tr from-[#702536]/8 via-[#DFBA71]/12 to-transparent rounded-full blur-3xl pointer-events-none -z-0" />

      {/* Main Content Container — Gen Z Editorial Luxury */}
      <div className="relative z-10 max-w-4xl mx-auto w-full text-center">
        {/* Editorial Sub-header Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="inline-flex items-center gap-2.5 px-5 py-1.5 rounded-full border border-[#C6A15B]/50 bg-[#FFF8EE]/95 shadow-xs mb-8"
        >
          <IslamicStar className="w-3.5 h-3.5 text-[#C6A15B]" />
          <span className="font-sans text-[11px] sm:text-xs uppercase tracking-[0.3em] text-[#702536] font-semibold">
            Wedding Celebration · Ahmednagar
          </span>
          <IslamicStar className="w-3.5 h-3.5 text-[#C6A15B]" />
        </motion.div>

        {/* Family Lineage / Groom's Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.25 }}
          className="space-y-2 mb-6"
        >
          <p className="font-cormorant text-base sm:text-lg md:text-xl text-[#702536]/90 tracking-wide font-light">
            Grandson of <span className="font-medium text-[#501623]">Late Professor Khalil Muzaffar Khan</span>
          </p>
          <p className="font-cormorant text-base sm:text-lg md:text-xl text-[#702536]/90 tracking-wide font-light">
            Son of <span className="font-medium text-[#501623]">Birjis Khalil Khan</span>
          </p>
        </motion.div>

        {/* Animated Gold Glowing Line Divider */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ duration: 1, delay: 0.35 }}
          className="max-w-md mx-auto my-5"
        >
          <GoldDivider />
        </motion.div>

        {/* Groom's Name (VISUAL FOCAL POINT) */}
        <motion.div
          initial={{ opacity: 0, y: 25, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="my-7 sm:my-10"
        >
          <h1 className="font-serif text-5xl sm:text-6xl md:text-8xl font-bold tracking-wider text-[#702536] drop-shadow-md">
            SHAHEZAD
          </h1>
          <p className="font-sans text-sm sm:text-xl md:text-2xl tracking-[0.35em] uppercase text-[#C6A15B] font-semibold mt-2">
            BIRJIS KHAN
          </p>
        </motion.div>

        {/* WEDS Calligraphic Flourish */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="relative my-4 flex items-center justify-center"
        >
          <div className="h-[1px] w-16 sm:w-28 bg-gradient-to-r from-transparent to-[#C6A15B]" />
          <span className="font-script text-3xl sm:text-5xl text-[#702536] px-4 -my-2 font-normal select-none">
            Weds
          </span>
          <div className="h-[1px] w-16 sm:w-28 bg-gradient-to-l from-transparent to-[#C6A15B]" />
        </motion.div>

        {/* Bride's Lineage and Name Display */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mt-4 mb-8 space-y-2"
        >
          {brideName ? (
            <div className="space-y-1">
              <h2 className="font-serif text-2xl sm:text-4xl text-[#702536] font-semibold tracking-wide">
                {brideName}
              </h2>
              <p className="font-cormorant text-base sm:text-xl text-[#702536]/85 tracking-wide font-light">
                Daughter of <span className="font-medium text-[#501623]">Ezaz Gafur Shaikh</span>
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <p className="font-cormorant text-lg sm:text-2xl text-[#702536]/90 tracking-wide font-light">
                Daughter of <span className="font-medium text-[#501623]">Ezaz Gafur Shaikh</span>
              </p>
            </div>
          )}
        </motion.div>

        {/* Date Highlight Banner — 22 NOVEMBER 2026 */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.85 }}
          className="inline-flex items-center gap-2.5 px-7 py-3 rounded-2xl bg-gradient-to-r from-[#702536]/5 via-[#C6A15B]/10 to-[#702536]/5 border border-[#C6A15B]/30 backdrop-blur-xs text-[#501623] shadow-xs"
        >
          <Calendar className="w-4 h-4 text-[#C6A15B]" />
          <span className="font-serif text-xs sm:text-sm font-bold tracking-[0.2em] uppercase">
            22 NOVEMBER 2026
          </span>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-14 flex flex-col items-center gap-2"
        >
          <button
            onClick={onScrollToCeremony}
            type="button"
            className="flex flex-col items-center text-[#C6A15B] hover:text-[#702536] transition-colors cursor-pointer group"
            aria-label="Scroll to wedding ceremony details"
          >
            <span className="font-sans text-[10px] tracking-[0.3em] uppercase font-semibold">
              Event Details
            </span>
            <ChevronDown className="w-4 h-4 animate-bounce group-hover:translate-y-1 transition-transform mt-0.5" />
          </button>
        </motion.div>
      </div>
    </section>
  );
};
