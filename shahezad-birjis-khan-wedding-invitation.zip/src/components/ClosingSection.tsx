import React from 'react';
import { motion } from 'motion/react';
import { GoldFloralCorner, IslamicStar } from './IslamicMotifs';

interface ClosingSectionProps {
  onReopenInvitation?: () => void;
  brideName?: string;
}

export const ClosingSection: React.FC<ClosingSectionProps> = () => {
  return (
    <footer className="relative py-20 sm:py-28 px-4 sm:px-6 bg-gradient-to-b from-[#FFF8EE] via-[#5C1C2A] to-[#40121C] text-[#FFF8EE] overflow-hidden">
      {/* Decorative Islamic Watermark on dark section */}
      <div className="absolute inset-0 islamic-pattern-dark opacity-30 pointer-events-none" />

      {/* Radial gold glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#DFBA71]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        {/* Animated Gold Framed Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9 }}
          className="relative rounded-3xl bg-gradient-to-b from-[#702536]/90 via-[#5C1C2A]/95 to-[#471420] border-2 border-[#DFBA71] p-8 sm:p-12 md:p-16 shadow-2xl"
        >
          {/* Gold Floral Corners */}
          <div className="absolute top-3 left-3 pointer-events-none">
            <GoldFloralCorner position="top-left" className="w-12 h-12 sm:w-16 sm:h-16" />
          </div>
          <div className="absolute top-3 right-3 pointer-events-none">
            <GoldFloralCorner position="top-right" className="w-12 h-12 sm:w-16 sm:h-16" />
          </div>
          <div className="absolute bottom-3 left-3 pointer-events-none">
            <GoldFloralCorner position="bottom-left" className="w-12 h-12 sm:w-16 sm:h-16" />
          </div>
          <div className="absolute bottom-3 right-3 pointer-events-none">
            <GoldFloralCorner position="bottom-right" className="w-12 h-12 sm:w-16 sm:h-16" />
          </div>

          {/* Inner hairline border */}
          <div className="absolute inset-3 sm:inset-4 rounded-2xl border border-dashed border-[#DFBA71]/40 pointer-events-none" />

          {/* Medallion */}
          <div className="w-10 h-10 rounded-full border border-[#DFBA71] mx-auto mb-4 flex items-center justify-center bg-[#5C1C2A] text-[#DFBA71]">
            <IslamicStar className="w-5 h-5 text-[#DFBA71]" />
          </div>

          <p className="font-serif text-xs uppercase tracking-[0.3em] text-[#DFBA71] font-semibold mb-3">
            With Humility &amp; Gratitude
          </p>

          {/* Sacred Quote / Closing Message */}
          <blockquote className="my-6">
            <p className="font-cormorant italic text-xl sm:text-2xl md:text-3xl text-[#FFF8EE] leading-relaxed max-w-xl mx-auto font-light">
              “With the blessings of Allah and our elders, we look forward to your gracious presence.”
            </p>
          </blockquote>

          {/* Gold Ornamental Divider */}
          <div className="flex items-center justify-center gap-3 my-6">
            <div className="h-[1px] w-20 bg-gradient-to-r from-transparent to-[#DFBA71]" />
            <div className="w-2 h-2 rotate-45 bg-[#DFBA71]" />
            <div className="h-[1px] w-20 bg-gradient-to-l from-transparent to-[#DFBA71]" />
          </div>

          {/* Birjis Khan & Family Focal Point with Final Gold Flourish */}
          <div className="space-y-1 my-7">
            <h2 className="font-serif text-2xl sm:text-4xl md:text-5xl font-bold tracking-wider text-[#DFBA71] drop-shadow-md">
              Birjis Khan &amp; Family
            </h2>
          </div>

          {/* Final Calligraphy / Floral flourish SVG */}
          <div className="w-32 sm:w-44 mx-auto my-4 text-[#DFBA71]/80">
            <svg viewBox="0 0 200 40" fill="none" className="w-full h-auto">
              <path
                d="M 10 20 C 50 5, 80 35, 100 20 C 120 5, 150 35, 190 20"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
              <circle cx="100" cy="20" r="3" fill="currentColor" />
              <circle cx="60" cy="18" r="1.5" fill="currentColor" />
              <circle cx="140" cy="18" r="1.5" fill="currentColor" />
            </svg>
          </div>
        </motion.div>

        {/* Small copyright / credit */}
        <p className="mt-8 text-xs font-serif tracking-widest text-[#EAD8B2]/70 uppercase">
          Birjis Khan &amp; Family · Ahmednagar · 2026
        </p>
      </div>
    </footer>
  );
};
