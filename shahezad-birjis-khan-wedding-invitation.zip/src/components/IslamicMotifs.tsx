import React from 'react';

// Authentic Arabic Bismillah Calligraphy Component
export const BismillahCalligraphy: React.FC<{
  className?: string;
  variant?: 'gold' | 'maroon';
}> = ({ className = '', variant = 'gold' }) => {
  return (
    <div className={`relative flex flex-col items-center justify-center text-center px-4 py-2 ${className}`}>
      {/* Decorative Top Rosette */}
      <div className="flex items-center gap-2 mb-2 opacity-80 pointer-events-none">
        <div className="h-[1px] w-10 sm:w-16 bg-gradient-to-r from-transparent to-[#C6A15B]" />
        <span className="text-[#C6A15B] text-xs">✦</span>
        <div className="h-[1px] w-10 sm:w-16 bg-gradient-to-l from-transparent to-[#C6A15B]" />
      </div>

      {/* Authentic Connected Arabic Text with correct RTL ligatures and high breathing room */}
      <div
        dir="rtl"
        lang="ar"
        className={`font-arabic text-2xl sm:text-3xl md:text-4xl leading-loose font-normal select-none tracking-normal py-1 ${
          variant === 'gold'
            ? 'gold-text-gradient-rich drop-shadow-[0_1px_2px_rgba(198,161,91,0.3)]'
            : 'text-[#702536] drop-shadow-sm'
        }`}
        style={{
          fontFamily: "'Noto Naskh Arabic', 'Amiri', 'Traditional Arabic', serif",
          fontFeatureSettings: '"kern" 1, "liga" 1, "calt" 1',
        }}
      >
        بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
      </div>

      {/* Delicate Gold Floral Baseline Accent (Placed strictly below text) */}
      <div className="flex items-center gap-2 mt-2 opacity-85 pointer-events-none">
        <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-r from-transparent via-[#C6A15B] to-[#DFBA71]" />
        <div className="w-1.5 h-1.5 rotate-45 border border-[#C6A15B] bg-[#FFF8EE]" />
        <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-l from-transparent via-[#C6A15B] to-[#DFBA71]" />
      </div>
    </div>
  );
};

// Antique Gold Corner Flourish
export const GoldFloralCorner: React.FC<{
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  className?: string;
}> = ({ position, className = 'w-16 h-16' }) => {
  const rotation =
    position === 'top-right'
      ? 'rotate-90'
      : position === 'bottom-right'
      ? 'rotate-180'
      : position === 'bottom-left'
      ? '-rotate-90'
      : '';

  return (
    <div className={`pointer-events-none select-none ${className} ${rotation}`}>
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        <defs>
          <linearGradient id={`cornerGrad-${position}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#DFBA71" />
            <stop offset="50%" stopColor="#C6A15B" />
            <stop offset="100%" stopColor="#987532" />
          </linearGradient>
        </defs>

        {/* Outer border lines with corner notch */}
        <path
          d="M 6 95 L 6 22 C 6 13, 13 6, 22 6 L 95 6"
          stroke={`url(#cornerGrad-${position})`}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />
        {/* Inner parallel accent */}
        <path
          d="M 14 95 L 14 26 C 14 19, 19 14, 26 14 L 95 14"
          stroke={`url(#cornerGrad-${position})`}
          strokeWidth="0.8"
          strokeDasharray="3 2"
          fill="none"
        />

        {/* Traditional Islamic arabesque leaf & floral curl */}
        <path
          d="M 18 18 C 28 28, 42 22, 45 35 C 38 40, 26 38, 22 30 Z"
          fill={`url(#cornerGrad-${position})`}
          opacity="0.85"
        />
        <path
          d="M 18 18 C 22 35, 38 40, 32 55 C 24 50, 18 40, 18 28 Z"
          fill={`url(#cornerGrad-${position})`}
          opacity="0.7"
        />
        <circle cx="20" cy="20" r="3.5" fill={`url(#cornerGrad-${position})`} />
        <circle cx="48" cy="18" r="2" fill={`url(#cornerGrad-${position})`} />
        <circle cx="18" cy="48" r="2" fill={`url(#cornerGrad-${position})`} />
      </svg>
    </div>
  );
};

// Symmetrical Islamic Ornamental Divider
export const GoldDivider: React.FC<{ className?: string; label?: string }> = ({
  className = 'my-6',
  label,
}) => (
  <div className={`flex items-center justify-center gap-3 select-none ${className}`}>
    <div className="h-[1px] flex-1 max-w-[120px] bg-gradient-to-r from-transparent via-[#C6A15B] to-[#DFBA71]" />
    
    <div className="flex items-center gap-1.5 text-[#C6A15B]">
      {/* Small side diamond */}
      <div className="w-1.5 h-1.5 rotate-45 border border-[#C6A15B] bg-[#FFF8EE]" />
      
      {/* Central 8-pointed star / Islamic medallion */}
      <svg viewBox="0 0 24 24" className="w-5 h-5 text-[#C6A15B] fill-current">
        <path d="M12 2L14.5 7L19.5 4.5L17 9.5L22 12L17 14.5L19.5 19.5L14.5 17L12 22L9.5 17L4.5 19.5L7 14.5L2 12L7 9.5L4.5 4.5L9.5 7L12 2Z" opacity="0.9" />
        <circle cx="12" cy="12" r="2.5" fill="#FFF8EE" />
      </svg>

      {/* Small side diamond */}
      <div className="w-1.5 h-1.5 rotate-45 border border-[#C6A15B] bg-[#FFF8EE]" />
    </div>

    {label && (
      <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-serif px-2">
        {label}
      </span>
    )}

    <div className="h-[1px] flex-1 max-w-[120px] bg-gradient-to-l from-transparent via-[#C6A15B] to-[#DFBA71]" />
  </div>
);

// Islamic Geometric 8-Pointed Star (Rub el Hizb)
export const IslamicStar: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 24 24" className={`fill-current ${className}`}>
    <path d="M12 2L14.5 7L19.5 4.5L17 9.5L22 12L17 14.5L19.5 19.5L14.5 17L12 22L9.5 17L4.5 19.5L7 14.5L2 12L7 9.5L4.5 4.5L9.5 7L12 2Z" />
    <circle cx="12" cy="12" r="2.5" fill="#FFF8EE" />
  </svg>
);

// Wax Seal Emblem Button Motif (for Invitation Opening)
export const RoyalWaxSeal: React.FC<{
  onClick?: () => void;
  className?: string;
  isOpening?: boolean;
}> = ({ onClick, className = '', isOpening = false }) => (
  <button
    type="button"
    onClick={onClick}
    aria-label="Open wedding invitation"
    className={`group relative rounded-full p-2 transition-transform duration-300 hover:scale-105 active:scale-95 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#C6A15B] focus:ring-offset-2 ${className}`}
  >
    {/* Outer golden halo glow */}
    <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#C6A15B] via-[#DFBA71] to-[#987532] blur-md opacity-60 group-hover:opacity-90 transition-opacity animate-pulse" />

    {/* Seal disc */}
    <div className="relative w-24 h-24 md:w-28 md:h-28 rounded-full bg-gradient-to-br from-[#702536] via-[#5C1C2A] to-[#40121C] shadow-2xl border-2 border-[#DFBA71] flex flex-col items-center justify-center overflow-hidden">
      {/* Concentric gold ring */}
      <div className="absolute inset-2 rounded-full border border-dashed border-[#DFBA71]/60" />
      
      {/* Monogram / Bismillah star */}
      <div className="relative flex flex-col items-center justify-center text-center">
        <svg viewBox="0 0 24 24" className="w-6 h-6 text-[#DFBA71] fill-current mb-0.5">
          <path d="M12 2L14.5 7L19.5 4.5L17 9.5L22 12L17 14.5L19.5 19.5L14.5 17L12 22L9.5 17L4.5 19.5L7 14.5L2 12L7 9.5L4.5 4.5L9.5 7L12 2Z" />
        </svg>
        <span className="font-serif text-[#DFBA71] font-bold text-xs tracking-widest uppercase">
          {isOpening ? 'OPENING' : 'OPEN'}
        </span>
        <span className="font-serif text-[10px] text-[#EAD8B2] tracking-wider">
          INVITATION
        </span>
      </div>

      {/* Shimmer sweep effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/15 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
    </div>
  </button>
);

// Mihrab Arch Background Contour (Placed strictly behind or below text layers)
export const MihrabArchBackdrop: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`pointer-events-none select-none ${className}`} aria-hidden="true">
    <svg viewBox="0 0 400 500" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full opacity-20">
      <path
        d="M 50 500 L 50 200 C 50 120, 140 60, 200 30 C 260 60, 350 120, 350 200 L 350 500"
        stroke="#C6A15B"
        strokeWidth="1.5"
      />
      <path
        d="M 65 500 L 65 210 C 65 140, 145 80, 200 55 C 255 80, 335 140, 335 210 L 335 500"
        stroke="#DFBA71"
        strokeWidth="0.8"
        strokeDasharray="4 3"
      />
      <circle cx="200" cy="28" r="4" fill="#C6A15B" />
    </svg>
  </div>
);
