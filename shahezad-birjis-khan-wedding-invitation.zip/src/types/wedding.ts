export interface WeddingDetails {
  groom: {
    name: string;
    fullName: string;
    fatherName: string;
    grandfatherName: string;
  };
  bride: {
    displayName: string;
    fatherName: string;
    isCustomized: boolean;
  };
  events: {
    ceremony: {
      title: string;
      date: string;
      dayOfWeek: string;
      timingPrayer: string;
      timeString: string;
      venueName: string;
      venueAddress: string;
      mapQuery: string;
      dateTimeIST: string; // ISO string in IST
    };
    reception: {
      title: string;
      date: string;
      dayOfWeek: string;
      timingNote: string;
      timeString: string;
      venueName: string;
      venueAddress: string;
      mapQuery: string;
      dateTimeIST: string;
    };
  };
  contacts: {
    name: string;
    phone: string;
    displayPhone: string;
    relation?: string;
  }[];
}
